function [M1,M2,M3]=derivation


f=inline('x^2') %inline pour definir une fonction % f=inline('x.^2') x vecteur
a=1; %x0=1
b=6; %x1=6
h=1;
M1 =[];
M2 =[];
M3 =[];
  for x=a+h:h:b-h
df1 = (f(x+h)-f(x))/h;
M1 = [M1 df1];
df2 = (f(x)-f(x-h))/h;
M2 = [M2 df2];
df3 = (f(x+h)-f(x-h))/2*h;
M3 = [M3 df3];
  end
x=[a+h:h:b-h];
z= 2.*x;
plot(x,M1)       %plot(x,M1,'r*',x,M2,'k.',x,M3);
hold on
plot(x,M2)
hold on
plot(x,M3,'r*')
hold on
plot(z,'y')

MM=[M1;M2;M3;z];
figure 
E1=[];
for i=1:length(MM)
    erreur = abs(z(i)-M1(i));
    E1 = [E1 erreur];
end
plot(E1,'b');
hold on
E2=[];
for i=1:length(MM)
    erreur = abs(z(i)-M2(i));
    E2 = [E2 erreur];
end
plot(E2,'b');
hold on
E3=[];
for i=1:length(MM)
    erreur = abs(z(i)-M3(i));
    E3 = [E3 erreur];
end
plot(E3,'b');
hold on 
plot(z,'*')
