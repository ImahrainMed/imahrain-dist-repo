function [c,t]=dichotomie
 f=inline('x.^3-(3*x)+1');
 
 a= -1;
 b= 1;

 eps=10^(-2);
 t=0;
 while(abs(b-a)>eps)
      c=(a+b)/2
     if(f(a)*f(c)<0)
         
             b=c;
            
             else
                 a=c;
     end      
 t=t+1;
 end
 t
