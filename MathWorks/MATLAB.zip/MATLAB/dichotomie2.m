function f=dichotomie

f=inline('cos(x)+sin(x)');
a=0;
b=pi;
 
t=0;

eps = 10^(-2);

while(abs(b-a)<0)
   
    
    
end