function trace
%x=1:0.5:20
%y=1/x.^2
%plot(x,y,'P')
syms x
f=INLINE (x.^2)
fplot(f,[1 20])
