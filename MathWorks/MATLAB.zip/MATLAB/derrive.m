function [DD,DG,DC]=derive
f=inline('sin(x)');
a=0;
b=pi/2;
h=pi/20;

DD=[];
DG=[];
DC=[];

for(x=a+h:h:b-h)
    fdd = (f(x+h)-f(x))/h;
    DD = [DD fdd];
    
    fdg = (f(x)-f(x-h))/h;
    DG = [DG fdg];
    
    fdc = (f(x+h)-f(x-h))/(2*h);
    DC = [DC fdc];
end

x=[a+h:h:b-h];
z=cos(x);
plot(z,'+')
hold on
plot(DD,'diamond') 
hold on
plot(DG,'<')
hold on
plot(DC,'-')


D =[DD;DG;DC;z];


EDD =[];
EDG =[];
EDC = [];

for (i=1:length(D))
    
    edd = abs(z(i)-DD(i));
    EDD = [EDD edd];
    
    edg = abs(z(i)-DG(i));
    EDG = [EDG edg];
    
    edc = abs(z(i)-DC(i));
    EDC = [EDC edc];
    
end

figure('name','Clacule Erreur de Deriv�e Gauche')
plot(EDD,'-')
hold on
plot(DD,'<')
hold on
plot(z,'+')

figure('name','Clacule Erreur de Deriv�e Droite')
plot (EDG,'-')
hold on
plot(DG,'<')
hold on
plot(z,'+')

figure('name','Clacule Erreur de Deriv�e Centrer')
plot(EDC,'-')
hold on
plot(DC,'<')
hold on
plot(z,'+')



