function tr=trapeze

f=inline('x.*sin(x)');
a=-pi;
b=pi;
 h=1;    %(2*pi)/3;
 N=3;
 
 TR = 0;
 
 for(i=1:N-1)
   TR = TR+2*f(a+(i*h));
 end
   tr = h/2*(f(a)+TR+f(b));
   
   
   