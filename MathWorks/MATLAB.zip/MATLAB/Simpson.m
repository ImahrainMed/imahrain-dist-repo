function sm=simpson

f=inline('x.*sin(x)');
a=-pi;
b=pi;
 h=1;%(2*pi)/3;
 N=3;
 
 SM = 0;

 R=0;
 for i=1:N-1
  if mod(i,2)==0
         R=2;
  else
          R=4;
   
  end   
      SM=SM+(f(a+(i*h))*R);   
 end
   sm = (h/3)*(f(a)+SM+f(b));
   