function Rd=rectangle
%tracer la function f sur l'intervalle x%
%x=[-pi:0.1:pi];
%f=x.*sin(x);

%plot(x,f);

%la deuxieme methode pour tracer la fonction f
f=inline('x.*sin(x)');
%fplot(f ,[-pi:pi]);
%la troisieme m�thode pour tracer la fonction f
%syms x;
%f=inline(x*sin(x));
%fplot(f,[-pi:pi]);
a= -pi;
b= pi;

N=3;
h= (pi-a)/N;
RD = 0;

for(i=1:b)
   RD = RD + f(a+(i*h)); 
end
Rd = RD*h;
%fplot(RG,'r');
  
  