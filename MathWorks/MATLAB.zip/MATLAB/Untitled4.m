lagrange

l =

     1

 
l =
 
2 - x
 
 
l =
 
(x/2 - 3/2)*(x - 2)
 
 
p =
 
(x/2 - 3/2)*(x - 2)
 

l =

     1

 
l =
 
x - 1
 
 
l =
 
-(x - 1)*(x - 3)
 
 
p =
 
(x/2 - 3/2)*(x - 2) - ((x - 1)*(x - 3))/4
 

l =

     1

 
l =
 
x/2 - 1/2
 
 
l =
 
(x/2 - 1/2)*(x - 2)
 
 
p =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
 
ans =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
lagrange

l =

     1

 
l =
 
2 - x
 
 
l =
 
(x/2 - 3/2)*(x - 2)
 
 
p =
 
(x/2 - 3/2)*(x - 2)
 

l =

     1

 
l =
 
x - 1
 
 
l =
 
-(x - 1)*(x - 3)
 
 
p =
 
(x/2 - 3/2)*(x - 2) - ((x - 1)*(x - 3))/4
 

l =

     1

 
l =
 
x/2 - 1/2
 
 
l =
 
(x/2 - 1/2)*(x - 2)
 
 
p =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
 
ans =
 
(11*x^2)/36 - (5*x)/3 + 85/36
 
 
ans =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
lagrange

l =

     1

 
l =
 
2 - x
 
 
l =
 
(x/2 - 3/2)*(x - 2)
 
 
p =
 
(x/2 - 3/2)*(x - 2)
 

l =

     1

 
l =
 
x - 1
 
 
l =
 
-(x - 1)*(x - 3)
 
 
p =
 
(x/2 - 3/2)*(x - 2) - ((x - 1)*(x - 3))/4
 

l =

     1

 
l =
 
x/2 - 1/2
 
 
l =
 
(x/2 - 1/2)*(x - 2)
 
 
p =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
 
ans =
 
(11*x^2)/36 - (5*x)/3 + 85/36
 
 
ans =
 
((x/2 - 1/2)*(x - 2))/9 - ((x - 1)*(x - 3))/4 + (x/2 - 3/2)*(x - 2)
 
W=[1,2,3]

W =

     1     2     3

W=[1,2,3];
W

W =

     1     2     3

V=[1 2 3];
W=[1,1/4,1/9];
p=polyfit(V,W,2);
p=polyfit(V,W,2)

p =

    0.3056   -1.6667    2.3611

lagrange

x =

     1


l =

     1


l =

     1


l =

     1


p =

     1


l =

     1


l =

     0


l =

     0


p =

     1


l =

     1


l =

     0


l =

     0


p =

     1

Undefined function 'expand' for input arguments of type 'double'.

Error in lagrange (line 21)
expand(p)
 
lagrange
Error: File: lagrange.m Line: 5 Column: 8
Invalid expression. Check for missing or extra characters.
 
lagrange

x =

     1


l =

     1


l =

     1


l =

     1


p =

     1


l =

     1


l =

     0


l =

     0


p =

     1


l =

     1


l =

     0


l =

     0


p =

     1


ans =

     1

lagrange

l =

     1


l =

    0.5000


l =

    0.3750


p =

    0.3750


l =

     1


l =

    0.5000


l =

    0.7500


p =

    0.5625


l =

     1


l =

    0.2500


l =

   -0.1250


p =

    0.5486


ans =

    0.5486

lagrange

l =

     1


l =

    0.5000


l =

    0.3750


p =

    0.3750


l =

     1


l =

    0.5000


l =

    0.7500


p =

    0.5625


l =

     1


l =

    0.2500


l =

   -0.1250


p =

    0.5486


ans =

    0.5486

y=polyval(p,1.5)

y =

    0.5486

lagrange

l =

     1


l =

    0.5000


l =

    0.3750


p =

    0.3750


l =

     1


l =

    0.5000


l =

    0.7500


p =

    0.5625


l =

     1


l =

    0.2500


l =

   -0.1250


p =

    0.5486

Warning: MATLAB has disabled some advanced graphics rendering features by switching to software OpenGL. For more
information, click here. 

ans =

    0.5486

lagrange

l =

     1


l =

    0.5000


l =

    0.3750


p =

    0.3750


l =

     1


l =

    0.5000


l =

    0.7500


p =

    0.5625


l =

     1


l =

    0.2500


l =

   -0.1250


p =

    0.5486


ans =

    0.5486

lagrange

l =

     1


l =

    0.5000


l =

    0.3750


p =

    0.3750


l =

     1


l =

    0.5000


l =

    0.7500


p =

    0.5625


l =

     1


l =

    0.2500


l =

   -0.1250


p =

    0.5486


ans =

    0.5486

plot(f,[1 5])
Undefined function or variable 'f'.
 
fplot(f,[1 5])
Undefined function or variable 'f'.
 
plot(f,[1 5])
Undefined function or variable 'f'.
 
f = 1/x^2;
Undefined function or variable 'x'.
 
x=1:0,2:5

x =

  1�0 empty double row vector


ans =

     2     3     4     5

x=1:0,2:5;

x =

  1�0 empty double row vector

y=1/(x.^2)
Error using  / 
Matrix dimensions must agree.
 
y=(1)/(x.^2)
Error using  / 
Matrix dimensions must agree.
 
y=1./(x.^2)

y =

  1�0 empty double row vector

x=[1:0.2:5]

x =

  Columns 1 through 11

    1.0000    1.2000    1.4000    1.6000    1.8000    2.0000    2.2000    2.4000    2.6000    2.8000    3.0000

  Columns 12 through 21

    3.2000    3.4000    3.6000    3.8000    4.0000    4.2000    4.4000    4.6000    4.8000    5.0000

y=(1./x.^2);
plot(x,y)

