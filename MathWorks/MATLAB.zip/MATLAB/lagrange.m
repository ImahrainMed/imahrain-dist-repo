function p= lagrange

V=[1,2,3];

g=[1./V.^3];
syms x 


p=0;
for(i=1:length(V))
    
        l=1
        for(j=1:length(V))
        
            if(i~=j)
            
                l=l*((x-V(j))/(V(i)-V(j)))
            end 
            
        end
        p=p+g(i)*l
        
end
%fplot(p,'r');
%p=polyfit(f,V,2);
%y=polyval(p,1.5);
%subplot(p,f,1.5);
%fplot(p,'r');
%expand(p);





        