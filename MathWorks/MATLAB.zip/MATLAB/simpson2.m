function sm=simpson

f=inline('x./(1+x.^2)');
a=0;
b=3;
 h=1;
 N=3;
 
 SM = 0;

 R=0;
 for i=1:N-1
  if mod(i,2)==0
         R=2;
  else
          R=4;
   
  end   
      SM=SM+(f(a+(i*h))*R);   
 end
   sm = (h/3)*(f(a)+SM+f(b));
   