function Rg=rectangle
%tracer la function f sur l'intervalle x%
%x=[-pi:0.1:pi];
%f=x.*sin(x);

%plot(x,f);

%la deuxieme methode pour tracer la fonction f
f=inline('x.*sin(x)');
%fplot(f ,[-pi:pi]);
%la troisieme m�thode pour tracer la fonction f
%syms x;
%f=inline(x*sin(x));
%fplot(f,[-pi:pi]);
a= -pi;
b= pi;

N=3;
h= (pi-a)/N;
RG = 0;

for(i=0:N-1)
   RG = RG + f(a+(i*h)); 
end
Rg = RG*h;
%fplot(RG,'r');
  
  