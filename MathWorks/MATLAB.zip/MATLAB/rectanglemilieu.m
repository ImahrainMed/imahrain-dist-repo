function Rm=rectangle
%tracer la function f sur l'intervalle x%
%x=[-pi:0.1:pi];
%f=x.*sin(x);

%plot(x,f);

%la deuxieme methode pour tracer la fonction f
f=inline('x.*sin(x)');
%fplot(f ,[-pi:pi]);
%la troisieme m�thode pour tracer la fonction f
%syms x;
%f=inline(x*sin(x));
%fplot(f,[-pi:pi]);
a= -pi;
b= pi;


h= (2*pi)/3;
N=3;
RM = (a+h)/2;



for(i=1:h/N:N)
   RM = RM + f((a+(i))/2); 
end
Rm = RM*h;
%fplot(RG,'r');
  
  