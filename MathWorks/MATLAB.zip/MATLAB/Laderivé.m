function derivation


f = inline('x^2') %inline pour definir une fonction
a=1; %x0=1
b=6; %x1=6
h=1;
M1 =[];
M2 =[];
M3 =[];
  for (x=a+h:h:b-h)
df1 = (f(a+h)-f(a))/h;
M1 = [M1 df1];
df2 = (f(a)-f(a-h))/h;
M2 = [M2 df2];
df3 = (f(a+h)-f(a-h))/2h;
M3 = [M3 df3];
  end
  


