function n=newton

